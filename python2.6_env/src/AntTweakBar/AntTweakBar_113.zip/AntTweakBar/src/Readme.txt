Under Windows, it is not necessary to rebuild AntTweakBar since a precompiled
version is provided in the /lib directory.

Under GNU/Linux, a precompiled version of the library (libAntTweakBar.so) is
provided in the /lib directory. But depending on your system, you may need 
to rebuild the library. To do so, type make in this /src directory.

To recompile AntTweakBar under Windows you may also need the DirectX SDK
(http://msdn.microsoft.com/directx).
