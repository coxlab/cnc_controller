# THIS FILE IS GENERATED FROM THE SETUP.PY. DO NOT EDIT.
"""
glumpy is  a small python library  for the rapid vizualization  of numpy arrays
(mainly two dimensional) that has  been designed with efficiency in mind, using
OpenGL. If you want to draw nice figures for inclusion in a scientific article,
you'd better use matplotlib. If you want  to have a sense of what's going on in
your simulation while it is running, then maybe glumpy can help you.
"""